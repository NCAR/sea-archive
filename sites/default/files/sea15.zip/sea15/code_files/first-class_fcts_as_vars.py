#=============================================================================
# Example of setting functions as variables in Python
#
# By Johnny Lin
# April 2015
#
# Copyright (c) 2015 by Johnny Lin.  For licensing, distribution 
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/pylib.shtml.
#=============================================================================


def area(radius, pi=3.14):
    area = pi * (radius**2) 
    return area

print( area(3) )
myarea = area
print( myarea(3) )
set = { 'value':3, 'area':area, 'area2':myarea }
print( set['area'](3) )
print( set['area'](set['value']) )
print( set['area2'](set['value']) )


#===== end file =====
